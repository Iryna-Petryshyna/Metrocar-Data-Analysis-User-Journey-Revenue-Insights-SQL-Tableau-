-- SQL-запит для аналізу поїздок залежно від часу доби
SELECT 
    EXTRACT(HOUR FROM rr.request_ts) AS hour_of_day, 
    ad.platform, 
    COALESCE(s.age_range, 'Unknown') AS age_range, 
    COUNT(rr.ride_id) AS number_of_rides 
FROM ride_requests rr 
LEFT JOIN signups s ON rr.user_id = s.user_id 
LEFT JOIN app_downloads ad ON ad.app_download_key = s.session_id 
WHERE rr.request_ts IS NOT NULL 
GROUP BY 
    EXTRACT(HOUR FROM rr.request_ts), ad.platform, COALESCE(s.age_range, 'Unknown') 
ORDER BY 
    hour_of_day, ad.platform, age_range;
