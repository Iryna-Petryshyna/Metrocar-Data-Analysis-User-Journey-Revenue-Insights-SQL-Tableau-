-- SQL-запит для аналізу кількості поїздок за днями тижня і віковими категоріями
SELECT 
    TO_CHAR(rr.request_ts, 'Day') AS day_of_week, 
    TO_CHAR(rr.request_ts, 'ID')::int AS weekday_number, 
    COALESCE(su.age_range, 'Not specified') AS age_group, 
    ad.platform, 
    COUNT(*) AS total_ride_requests 
FROM ride_requests rr 
JOIN signups su ON rr.user_id = su.user_id 
JOIN app_downloads ad ON su.session_id = ad.app_download_key 
GROUP BY 
    TO_CHAR(rr.request_ts, 'Day'), 
    TO_CHAR(rr.request_ts, 'ID'), 
    COALESCE(su.age_range, 'Not specified'), 
    ad.platform 
ORDER BY 
    weekday_number, age_group, ad.platform;
