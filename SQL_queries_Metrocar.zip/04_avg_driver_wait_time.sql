-- SQL-запит для підрахунку середнього часу очікування водія
SELECT 
    ad.platform, 
    COALESCE(su.age_range, 'Not specified') AS age_group, 
    ROUND(AVG(EXTRACT(EPOCH FROM (rr.accept_ts - rr.request_ts)) / 60), 2) AS avg_driver_wait_time_min 
FROM ride_requests rr 
JOIN signups su ON rr.user_id = su.user_id 
JOIN app_downloads ad ON su.session_id = ad.app_download_key 
WHERE rr.accept_ts IS NOT NULL AND rr.request_ts IS NOT NULL 
GROUP BY 
    ad.platform, su.age_range 
ORDER BY 
    avg_driver_wait_time_min DESC;
