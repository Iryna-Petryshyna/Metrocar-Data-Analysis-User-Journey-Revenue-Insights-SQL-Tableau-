-- SQL-запит для аналізу транзакцій
SELECT 
    ts.ride_id, 
    ts.transaction_ts, 
    ts.purchase_amount_usd, 
    ts.charge_status, 
    ad.platform, 
    COALESCE(su.age_range, 'Not specified') AS age_group 
FROM transactions ts 
JOIN ride_requests rr ON ts.ride_id = rr.ride_id 
JOIN signups su ON rr.user_id = su.user_id 
JOIN app_downloads ad ON su.session_id = ad.app_download_key 
ORDER BY 
    ts.transaction_ts DESC;
