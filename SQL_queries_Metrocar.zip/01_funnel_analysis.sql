-- SQL-запит для побудови воронки користувачів і поїздок
SELECT 
    funnel_step, 
    funnel_name, 
    platform, 
    age_range, 
    SUM(number_of_users) AS total_users, 
    SUM(number_of_rides) AS total_rides 
FROM funnel_analysis 
GROUP BY 
    funnel_step, funnel_name, platform, age_range 
ORDER BY 
    funnel_step, platform, age_range;
